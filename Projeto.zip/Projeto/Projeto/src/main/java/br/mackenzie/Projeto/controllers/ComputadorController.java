package br.mackenzie.Projeto.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.mackenzie.Projeto.entities.Computador;
import br.mackenzie.Projeto.repositories.ComputadorRepository;

@RestController
@RequestMapping("/computadores")
public class ComputadorController {
    @Autowired
    private ComputadorRepository repositorio;

    @GetMapping
    public List<Computador> getComputadores(
            @RequestParam(name = "marca", required = false) String marca) {
        if (marca == null) {
            return repositorio.findAll();
        }
        return repositorio.findByMarcaContainingIgnoreCase(marca);
    }

    @GetMapping("/{id}")
    public Computador getComputadorById(@PathVariable Long id) {
        Optional<Computador> computador = repositorio.findById(id);

        if (computador.isPresent()) {
            return computador.get();
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Computador não encontrado");
        }
    }

    @PostMapping
    public Computador setComputador(@RequestBody Computador computador) {
        return repositorio.save(computador);
    }

    @PutMapping("/{id}")
    public Computador updateComputador(@RequestBody Computador computador, @PathVariable Long id) {
        // Verifique se o livro com o id especificado existe no repositório.
        Optional<Computador> computadorExistente = repositorio.findById(id);

        System.out.println(computador);
        System.out.println(id);

        if (computadorExistente.isPresent()) {
            Computador computadorEncontrado = computadorExistente.get();

            // Atualize os campos do livro com as informações fornecidas no corpo da
            // solicitação.
            computadorEncontrado.setMarca(computador.getMarca());
            computadorEncontrado.setProcessador(computador.getProcessador());
            computadorEncontrado.setQuantidadeRAM(computador.getQuantidadeRAM());
            computadorEncontrado.setTamanhoDisco(computador.getTamanhoDisco());

            // Salve o computador atualizado no repositório.
            repositorio.save(computadorEncontrado);

            return computadorEncontrado;
        } else {
            // Se o computador não existe, você pode lançar uma exceção ou retornar um
            // código de
            // status HTTP apropriado.
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Computador não encontrado");
        }
    }

    @DeleteMapping("/{id}")
    public void deleteComputador(@PathVariable Long id) {
        // Verifique se o livro com o id especificado existe no repositório.
        Optional<Computador> computadorExistente = repositorio.findById(id);

        if (computadorExistente.isPresent()) {
            // Se o computador existe, exclua-o do repositório.
            repositorio.delete(computadorExistente.get());
        } else {
            // Se o computador não existe, você pode lançar uma exceção ou retornar um
            // código de
            // status HTTP apropriado.
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Computador não encontrado");
        }
    }

}
