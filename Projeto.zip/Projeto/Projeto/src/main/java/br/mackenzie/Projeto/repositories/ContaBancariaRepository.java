package br.mackenzie.Projeto.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import br.mackenzie.Projeto.entities.ContaBancaria;

public interface ContaBancariaRepository extends JpaRepository<ContaBancaria, Long> {
    public List<ContaBancaria> findByNomeTitularContainingIgnoreCase(String nomeTitular);
    public List<ContaBancaria> findByNomeTitularOrId(String nomeTitular, Long id);
}

