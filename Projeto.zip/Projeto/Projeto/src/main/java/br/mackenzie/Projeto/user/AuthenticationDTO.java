package br.mackenzie.Projeto.user;

public record AuthenticationDTO(String login, String password) {
    
}
