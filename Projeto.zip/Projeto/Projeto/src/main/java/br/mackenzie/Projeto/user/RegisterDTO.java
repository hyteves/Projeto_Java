package br.mackenzie.Projeto.user;

public record RegisterDTO(String login, String password, UsuarioRole role) {
    
}
